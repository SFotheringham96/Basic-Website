document.getElementById('alertButton').onclick = function () {
    alert('Button clicked!');
};
