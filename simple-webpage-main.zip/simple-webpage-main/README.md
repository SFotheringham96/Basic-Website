Features:
Header: Includes a simple navigation bar with links.
Gallery Section: Three divs holding an image and text, styled with Flexbox.
About Section: Includes a button with an onclick event.
Contact Section: A functional form for user interaction.
Footer: A simple footer with copyright information.
